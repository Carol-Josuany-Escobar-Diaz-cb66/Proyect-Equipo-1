from django.db import models

# Create your models here.

class Usuario(models.Model):
    NombreUsuario = models.CharField(max_length=500)
    ApellidoUsuario = models.CharField(max_length=500)
    FechaNacimiento = models.DateField()
    Direccion = models.CharField(max_length=500)
    Telefono = models.CharField(max_length=500)