from django.http.response import JsonResponse
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from .models import Usuario
import json
# Create your views here.

class UsuarioView(View):
    
    @method_decorator(csrf_exempt)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)
    
    def get(self,request,id=0):
        if (id>0):
            usuarios=list(Usuario.objects.filter(id=id).values())
            if len(usuarios) > 0:
                usuario=usuarios[0]
                datos={'message':"Success",'usuario':usuario}
            else:
                datos={'message':"User not found..."}
            return JsonResponse(datos)
        else:
            usuarios=list(Usuario.objects.values())
            if len(usuarios)>0:
                datos={'message':"Success",'usuarios':usuarios}
            else:
                datos={'message':"Users not found..."}
            return JsonResponse(datos)
    
    
    def post(self,request):
        # print(request.body)
        jd=json.loads(request.body)
        # print(jd)
        Usuario.objects.create(NombreUsuario=jd['NombreUsuario'],ApellidoUsuario=jd['ApellidoUsuario'],
                               FechaNacimiento=jd['FechaNacimiento'],Direccion=jd['Direccion'],Telefono=jd['Telefono'])
        datos = {'message': "Success"}
        return JsonResponse(datos)
    
    
    def put(self,request,id):
        jd=json.loads(request.body)
        usuarios=list(Usuario.objects.filter(id=id).values())
        if len(usuarios) > 0:
            usuario=Usuario.objects.get(id=id)
            usuario.NombreUsuario=jd['NombreUsuario']
            usuario.ApellidoUsuario=jd['ApellidoUsuario']
            usuario.FechaNacimiento=jd['FechaNacimiento']
            usuario.Direccion=jd['Direccion']
            usuario.Telefono=jd['Telefono']
            usuario.save()
            datos = {'message': "Success"}
        else:
            datos={'message':"User not found..."}
        return JsonResponse(datos)
    
    def delete(self,request,id):
        usuarios=list(Usuario.objects.filter(id=id).values())
        if len(usuarios) > 0:
            Usuario.objects.filter(id=id).delete()
            datos = {'message': "Success"}
        else:
            datos={'message':"User not found..."}
        return JsonResponse(datos)

class Ambulancia(View):
    @method_decorator(csrf_exempt)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)
    
    def post(self, request):
        #return JsonResponse({'resultado':"jijijiji"})
        jd=json.loads(request.body)
        if jd['valida']=="si" :
            return JsonResponse({'resultado':"jijijiji"})
        else:
            return JsonResponse({'resultado':"jojojojoojo"})