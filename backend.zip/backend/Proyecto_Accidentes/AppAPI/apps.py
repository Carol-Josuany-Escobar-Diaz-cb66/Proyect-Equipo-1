from django.apps import AppConfig


class AppapiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'AppAPI'
